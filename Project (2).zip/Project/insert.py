import sqlite3,sys
'''
dsClient=[[1,'Ishit','abcdd3452r','9039492376','Wakad,Pune','ishit@gmail.com'],
    [2,'Raj','bsdrt1568e','9293014983','Aundh,Pune','raj2002@yahoo.com'],
    [3,'Ajay','kjhrt3450w','8234756245','Baner,Pune','ajcool@gmail.com'],
    [4,'Vijay','ghmsj4552e','7643209453','Hadapsar,Pune','vj25@hotmail.com'],
    [5,'Dinesh','kjhnd4569d','789435875','Pimpri,Pune','dinesh@gmail.com']]
'''

dsTxn=[(1,1,'RELIANCE',711.10,20,14222.0,'2017-08-12','NSE'),
       (2,1,'SUNPHARMA',648,40,25920.0,'2016-07-15','BSE'),
       (3,1,'WIPRO',998.05,40,39922.0,'2016-07-22','BSE'),
       (4,2,'ASHOKLEY',91.50,50,4575.0,'2017-09-29','NSE'),
       (5,2,'TATASTEEL',724.92,20,14498.4,'2017-11-01','NSE'),
       (6,3,'DMART',300,50,15000.0,'2017-03-06','BSE'),
       (7,3,'TCS',1140,30,34200.0 ,'2015-07-08','NSE'),
       (8,4,'PNB',210,50,10500.0,'2014-03-09','BSE'),
       (9,4,'ITC',244.22,30,7326.6,'2016-01-15','NSE'),
       (10,5,'CDSL',259.92,40,10396.8,'2017-05-10','BSE'),
       (11,5,'NTPC',192.34,50,9617.0,'2016-12-15','NSE')]

try:
          db=sqlite3.connect('Stocks')
          cursor=db.cursor()   
          cursor.executemany('Insert into Txn values(?,?,?,?,?,?,?,?)',dsTxn)
          #cursor.execute('create table Transaction (Id int,ClientId int REFERENCES Client(Id)(,Symbol varchar(10),PAN varchar(50),Contact varchar(20),Address varchar(100))')

except Exception as E:
          print 'Error',E
          sys.exit(1)
else:
          db.commit()
db.close()
