import sqlite3,sys

try:
    db=sqlite3.connect('Stocks')
    cursor=db.cursor()
    #cursor.execute('create table Client (Id int PRIMARY KEY,Name varchar(50) NOT NULL,PAN varchar(50) NOT NULL,Contact varchar(20) NOT NULL,Address varchar(100) NOT NULL),Email varchar(50)')
    #cursor.execute('create table Txn (Id int NOT NULL,ClientId int REFERENCES Client(Id),Symbol varchar(10) NOT NULL,BuyPrice float NOT NULL,Quantity int NOT NULL,Total_inv float,PurchaseDate Date NOT NULL,Exchange varchar(10) NOT NULL)')
except Exception as E:
    print 'Error',E
    sys.exit(1)
    
