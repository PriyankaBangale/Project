import os,sqlite3,sys,update

os.chdir('C:\Users\IBM_ADMIN\Desktop\study material\Python_class\Sample programs\Project')

script,Cid=sys.argv

try:
    db=sqlite3.connect('Stocks')
    cursor=db.cursor()
    cursor.execute('select ClientId from Txn')
except Exception as E:
    print 'Error',E
    sys.exit(1)
else:
    clientid=[str(i) for a in cursor.fetchall() for i in a]

db.close()

if clientid.count(Cid)==0:
    print 'Please enter valid Client Id'
    sys.exit(1)
else:
    print 'Checking Live prices...'
    update.doupdate(Cid)
    
