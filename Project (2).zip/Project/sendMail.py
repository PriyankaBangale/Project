def sendemail(to_addr,rep):
    import smtplib
    from os.path import basename
    from email.mime.application import MIMEApplication
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    from email.utils import COMMASPACE, formatdate

    from_addr = 'ishitpatni@gmail.com'
    subject = 'Testing'
    message = 'Testing'

    server='smtp.gmail.com:587'
    login = 'ishitpatni'
    password = 'ishitgmail123'

    msg=MIMEMultipart()
    msg['From'] =from_addr
    msg['To'] = to_addr
    msg['Date'] = formatdate(localtime=True)
    msg['Subject'] = subject

    msg.attach(MIMEText(message))

    with open(rep,'rb') as fil:
        part=MIMEApplication(
            fil.read(),
            Name=basename(rep)
            )
    part['Content-Disposition'] = 'attachment; filename="%s"' % basename(rep)
    msg.attach(part)

    smtp=smtplib.SMTP(server)
    smtp.starttls()
    smtp.login(login,password)
    smtp.sendmail(from_addr,to_addr,msg.as_string())
    smtp.close()
    
