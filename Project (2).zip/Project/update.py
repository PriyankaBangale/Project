def doupdate(Cid):
    import os,urlscrap,sys,sqlite3,xlwrt
    pf=[]

    os.chdir('C:\Users\IBM_ADMIN\Desktop\study material\Python_class\Sample programs\Project')

    quote=urlscrap.urlscrap(Cid)

    try:
        db=sqlite3.connect('Stocks')
        cursor=db.cursor()
        cursor.execute('select Id,Symbol,Total_inv,Quantity from Txn where ClientId=?',Cid)
    except Exception as E:
        print 'Error',E
        sys.exit(1)
    else:
        for a in cursor.fetchall():
            i=quote[str(a[1])][0]
            j=quote[str(a[1])][1]
            k=float(a[3])*quote[str(a[1])][0]
            l=quote[str(a[1])][2]
            m=float(str(round((quote[str(a[1])][0]*a[3]-a[2])*100/(quote[str(a[1])][0]*a[3]),2)))
            n=a[0]
            pf.append([i,j,k,l,m,n])
            #cursor.execute('Update Txn set LivePrice=?,YearLow=?,CurrentValue=?,YearHigh=?,Change=? where Id=?',(i,j,k,l,m,n))

    db.close()

    #print 'pf created'


    try:
        db=sqlite3.connect('Stocks')
        cursor=db.cursor()
        cursor.executemany('Update Txn set LivePrice=?,YearLow=?,CurrentValue=?,YearHigh=?,Change=? where Id=?',pf)
    except Exception as E:
        print 'Error while updating to db:',E
        sys.exit(1)
    else:
        db.commit()
        print 'Update successful'

    db.close()
    try:
        db=sqlite3.connect('Stocks')
        cursor=db.cursor()
        a=cursor.execute('select ClientId,Symbol,BuyPrice,Quantity,Total_inv,PurchaseDate,Exchange,LivePrice,CurrentValue,YearHigh,YearLow,Change from Txn where ClientId=?',Cid).fetchall()
        b=cursor.execute('select Name,Email from Client where Id=?',Cid).fetchall()        
    except Exception as E:
        print 'Error:',E
        sys.exit(1)
    else:
        db.close()
    print 'Preparing Excel Report...'    
    xlwrt.writexl(a,b)
