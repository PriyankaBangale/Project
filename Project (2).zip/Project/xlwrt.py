def writexl(a,b):
    import xlwt,sendMail,sys
    try:
        Namefmt=xlwt.Style.easyxf('''borders: left thin, right thin, top thin, bottom thin;pattern: pattern solid, fore_colour red;''')
        Colnamefmt=xlwt.Style.easyxf('''borders: left thin, right thin, top thin, bottom thin;pattern: pattern solid, fore_colour yellow;''')
        Totalfmt=xlwt.Style.easyxf('''borders: left thin, right thin, top thin, bottom thin;pattern: pattern solid, fore_colour green;''')
        Tablefmt=xlwt.Style.easyxf('''borders: left thin, right thin, top thin, bottom thin''')
        c=['ClientId','Symbol','Buy Price','Quantity','Total investment','Purchase Date','Exchange','Current Price','Total current Value','52-Week High','52-Week Low','Change(%)']
        book = xlwt.Workbook()
        sh = book.add_sheet("PySheet1")
        sh.write(0,0,'Portfolio details for {}'.format(b[0][0]),Namefmt)
        
        total_inv=0
        current_inv=0
        change=0
        
        for i in a:
            total_inv+=i[4]
            current_inv+=i[8]
            
        change=(current_inv-total_inv)*100/total_inv        
                
        d=0
        for name in c:
            sh.write(1,d,name,Colnamefmt)
            d+=1
    
        x=2
        y=0

        for i in a:
            for j in i:
                sh.write(x,y,j,Tablefmt)
                y+=1
            x+=1
            y=0

            
        sh.write(x,0,'Total',Totalfmt)
        sh.write(x,4,total_inv,Totalfmt)
        sh.write(x,8,current_inv,Totalfmt)
        sh.write(x,11,round(change,2),Totalfmt)

        
        rep="C:\Users\IBM_ADMIN\Desktop\study material\Python_class\Sample programs\Project\Reports\Portfolio_Report_{}.xls".format(str(b[0][0]))
        book.save(rep)

    except Exception as E:
        print 'Error while writing to excel',E
    else:
        print 'Report created successfully...'
        print 'Preparing to send Email...'

        try:
            sendMail.sendemail(str(b[0][1]),rep)
        except Exception as E:
            print 'Error sending mail:',E
            sys.exit(1)
        else:
            print 'Email sent successfully.'
        
 

