def urlscrap(Cid):
    import sqlite3,sys,urllib,re
    sym=[]
    quote={}
    pf=[]
    try:
        db=sqlite3.connect('Stocks')
        cursor=db.cursor()
        cursor.execute('select distinct(Symbol) from Txn where ClientId=?',Cid)
    except Exception as E:
        print 'Error',E
        sys.exit(1)
    else:
        for a in cursor.fetchall():
            for i in a:
                sym.append(str(i))

    baseUrl='http://finance.google.com/finance?q='
    
    for i in sym:
        Url=baseUrl+i
        fil=urllib.urlopen(Url)
        obj=fil.read()
        m1=re.search('<span id="ref_\d+_l">(.*)</span>',obj)
        m2=re.search('<tr>\n<td class="key"\n          data-snapfield="range_52week">52 week\n</td>\n<td class="val">(.*) - (.*)\n</td>\n</tr>',obj)
        quote[i]=[float(m1.group(1).replace(',','')),float(m2.group(1).replace(',','')),float(m2.group(2).replace(',',''))]

    return quote
    db.close()    
        
        

